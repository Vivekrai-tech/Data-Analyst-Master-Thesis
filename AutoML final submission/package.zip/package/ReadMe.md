----- Package -----
This package can be used when put in a particular folder where the code is run

Use this syntax:
 from py_TransferLearning_Package import *

You will be able to use the build function and the model function